# minecraft-serwer-start.sh
minecraft-serwer-start.sh

git status 
Linux - git add . && git commit -m "update" && git push 

sudo apt-get install dos2unix
 dos2unix start.sh