
# Aktualna data i czas w formacie "DD-MM-YYYY_HH-MM-SS"
DATE=$(date +"%d-%m-%Y_%H-%M-%S")
# Aktualna data i czas w formacie "DD-MM-YYYY"
DATE2=$(date +"%d-%m-%Y")
# Aktualna data i czas w formacie "YYYY-MM-DD"
DATE3=$(date +"%Y-%m-%d 00:00:00")
# Aktualna data i czas w formacie "DD-MM-YYYY HH-MM-SS"
DATE4=$(date +"%d.%m.%Y %H:%M:%S")
# Aktualna data i czas w formacie "YYYY-MM-DD_HH.MM.SS"
DATE5=$(date +"%Y-%m-%d_%H.%M.%S")
